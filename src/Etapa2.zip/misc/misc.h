#ifndef MISC_H
#define MISC_H

#include <cstdint>

/*
uint64_t bsf(uint64_t board) {
    uint64_t res;
    __asm__("bsf %1, %0" : "=g"(res) : "r"(board));
    return res;
}

uint64_t bsr(uint64_t board) {
    uint64_t res;
    __asm__("bsr %1, %0" : "=g"(res) : "r"(board));
    return res;
}*/

#endif