#include "xboardInterface.h"

XBoardInterface::XBoardInterface() {
	std::ios::sync_with_stdio(false);
	std::cout.setf(std::ios::unitbuf);
}