#ifndef XBOARDINTERFACE_H
#define XBOARDINTERFACE_H

#include <iostream>
#include "../bitboard/bitboard.h"
#include "../move/move.h"

//Comenzile force, go si new o sa le fac eu
//Resign nu implementam
//aveti si move.h pt a vedea cum arata structura, nu tb sa faceti nimic

class XBoardInterface {
	public:
	XBoardInterface();
	std::string name = "3CheckRapist";
};

#endif